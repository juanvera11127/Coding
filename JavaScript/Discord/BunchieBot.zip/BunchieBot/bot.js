var Discord = require('discord.io');
var logger = require('winston');
var auth = require('./auth.json');
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
var Twitter = require('twitter');

var client = new Twitter( {
	consumer_key:			'531hAGw25FFa9p2URKgKJMOqh'
	,consumer_secret:		'ycVlGvVFPwUsSPdIMPbD7ooPm0iZHdEsO4tUFwljHBHghsE98N'
	,access_token_key:		'842110915428343808-hDTIT8b9w2cozefUKP9xkXArmMnGdMk'
	,access_token_secret:	'yUBx1g8LDquKmqze9xux7rxfHjnWyrHmYdxkKDxv3Qhtw'
});

// Configure logger settings
logger.remove(logger.transports.Console);
logger.add(new logger.transports.Console, {
    colorize: true
});
logger.level = 'debug';
// Initialize Discord Bot
var bot = new Discord.Client({
   token: auth.token,
   autorun: true
});
bot.on('ready', function (evt) {
    logger.info('Connected');
    logger.info('Logged in as: ');
    logger.info(bot.username + ' - (' + bot.id + ')');
});
bot.on('message', function (user, userID, channelID, message, evt) {
    // Our bot needs to know if it will execute a command
    // It will listen for messages that will start with `!`
	var args = message.split(' ');
    if (message.substring(0, 1) == '!' && user != "BunchieBot") {
        args = message.substring(1).split(' ');
		var cmd = args[0];
        args = args.splice(1);
        switch(cmd) {
            
            case 'fact':
				var ourRequest = new XMLHttpRequest();
				var toSend;
				ourRequest.open('GET', 'http://api.icndb.com/jokes/random?firstName=Bunchie&amp;lastName=Vera'); // false for synchronous request
				ourRequest.onload = function() {
					var ourData = JSON.parse(ourRequest.responseText);
					toSend = ourData.value.joke;
					bot.sendMessage({
                    to: channelID,
                    message: toSend
                });
				};
				ourRequest.send();
				break;
	        
			case 'cat':
			
				var ourRequest = new XMLHttpRequest();
				var pic;
				ourRequest.open('GET', 'https://api.thecatapi.com/v1/images/search?', true);
				ourRequest.onload = function() {
					var ourData = JSON.parse(ourRequest.responseText);
					pic = ourData[0].url;
					bot.sendMessage({
						to: channelID,
						message: "Here's a cat pic.",
						embed: { 'image': { 'url': pic}
						}
					
					});
					
				};
				ourRequest.send();
				break;

			
			
			
			case 'uwu':
				var toReturn = "";
				var word = "";
				
				for(var i = 0; i < args.length; i++) {
					word = args[i].toLowerCase();
					switch(word) {
						case 'hello':
						word = 'hewwo';
						break;
						case 'you' || 'u':
						word = 'woo';
						break;
					}
					for(var j = 0; j < word.length; j++) {
						if(j+1 < word.length) {
							
							if(word.charAt(j) == "r"|| word.charAt(j) == "l") {
								if(j == 0 && isVowel(word.charAt(j+1)) || !isVowel(word.charAt(j-1)) && isVowel(word.charAt(j+1))) {
									word = word.substring(0, j) + "w" + word.substring(j+1);
								}
							}
							if(word.charAt(j) == "m" && isVowel(word.charAt(j+1))) {
								word = word.substring(0,j+1) + "w" + word.substring(j+1);
								j++;
								
							}
						}
					}			
					
					word = word.toUpperCase();
					toReturn += " " + word;
					
				}
				
				
				toReturn += " ~UWU";
				bot.sendMessage({
                    to: channelID,
                    message: toReturn
                });		
				break;
				
				
				
				
			case 'help':
					bot.sendMessage({
                    to: channelID,
                    message: "!uwu for uwu text generator (warning: there may be sound), !fact for a fun fact"
					});
				break;
			
			case 'tweet':
				if(user == "bunchiesonfire") {
					message = message.substring(7);
						
					client.post('statuses/update', {status: message},  function(error, tweet, response) {
						if(error) throw error;
						console.log(tweet);  // Tweet body.
						bot.sendMessage({
							to: channelId,
							message: "Tweeted!"
						});
					});
				}
				else {
					bot.sendMessage({
						to: channelID,
						message: "You are not bunchiesonfire so you can't tweet for him bro"
					});
				}
				break;
				
		}

    }
    else if (message.includes("bunchie") && user != "BunchieBot") {
		message = message.toLowerCase();

        bot.sendMessage({
            to: channelID,
            message: "did someone say BUNCHIE????"
		});
	}
	else {
		var toReply = '';
		var isReply = false;
		var count = 0;
		for(var i = 0; i < args.length; i++) {
			if(args[i].toLowerCase() == "im" || args[i].toLowerCase() == "i'm") {
				if(i < args.length) {
					toReply = message.substring(count+(args[i].toLowerCase() == "im" ? 3 : 4));
					isReply = true;
				}
			}
			count += args[i].length + 1;
		}
	
		if(isReply && user != "BunchieBot") {
			bot.sendMessage({
				to: channelID,
				message: "Hi " + toReply + ", I'm Bunchie"
			});		
		}
	}
});

function isVowel(a) {
	return (a == "a" || a == "e" || a == "i" || a == "o" || a == "u" || a == "y");
}